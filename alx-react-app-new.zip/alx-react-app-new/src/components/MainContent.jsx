function MainContent() {
  return (
    <main style={{ padding: '20px', backgroundColor: '#f4f4f4', minHeight: '200px' }}>
      <p>I love to visit New York, Paris, and Tokyo.</p>
    </main>
  );
}

export default MainContent;